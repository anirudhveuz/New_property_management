from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views
urlpatterns = [
    path('',views.login),
    path('dashboard',views.dashboard,name='dashboard'),
    path('Properties',views.Properties),
    path('new-property',views.new_property,name='new-property'),
    path('property-detail',views.property_detail),
    path('new-lease',views.new_lease,name='new-lease'),
    path('lease-detail',views.lease_detail,name='lease-detail'),
    path('units',views.units,name='units'),
    path('my-tenants',views.my_tenants),
    path('my_tenants',views.my_tenants),
    path('Reports',views.Reports,name='Reports'),
    path('documents_files',views.documents_files,name='documents_files'),
    path('income',views.income,name='income'),
    path('users',views.users,name='users'),
    path('Maintenance',views.Maintenance),
    path('analytics_report',views.analytics_report)
]

from django.shortcuts import render

# Create your views here.


def login(request):
    return render(request,'login.html')


def dashboard(request):
    return render(request,'dashboard.html')


def Properties(request):
    return render(request,'Properties.html')

def new_property(request):
    return render(request,'new_property.html')

def property_detail(request):
    return render(request,'property_detail.html')

def new_lease(request):
    return render(request,'new_lease.html')



def lease_detail(request):
    return render(request,'lease_detail.html')



def units(request):
    return render(request,'units.html')

def my_tenants(request):
    return render(request,'my_tenants.html')


def Reports(request):
    return render(request,'Reports.html')

def documents_files(request):
    return render(request,'documents_files.html')



def income(request):
    return render(request,'income.html')

def users(request):
    return render(request,'users.html')


def Maintenance(request):
    return render(request,'Maintenance.html')


def analytics_report(request):
    return render(request,'analytics_report.html')